import { Router } from "express";
import * as UserController from "./user.controller.js";

export const userRouter = Router();
userRouter.post("/", UserController.createUser);
