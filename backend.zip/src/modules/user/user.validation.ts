import z from "zod";

export const createUserSchema = z.object({
  name: z.string().min(2),
  email: z.email(),
  password: z.string().min(8),
  phone: z.string().optional(),
});

export type CreateUserInput = z.infer<typeof createUserSchema> 